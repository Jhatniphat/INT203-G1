<script setup></script>

<template>
  <div>
    <h2
      class="flex justify-center text-red-600 font-semibold text-3xl p-20 bg-white shadow-lg"
    >
      Page Not Found
    </h2>
  </div>
</template>

<style scoped></style>
