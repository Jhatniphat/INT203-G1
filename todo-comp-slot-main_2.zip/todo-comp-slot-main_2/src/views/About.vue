<script setup></script>

<template>
  <div>
    <h2
      class="flex justify-center font-semibold text-xl p-20 bg-white shadow-lg"
    >
      B.Sc.IT, School of Information Technology, KMUTT
    </h2>
  </div>
</template>

<style scoped></style>
