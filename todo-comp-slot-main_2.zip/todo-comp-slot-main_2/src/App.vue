<script setup>
import Nav from './views/Nav.vue'
</script>

<template>
  <div class="w-full">
    <!-- <ProductList /> -->
    <Nav />
    <router-view />
  </div>
</template>

<style scoped></style>
